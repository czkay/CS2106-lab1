/*************************************
* Lab 1 Exercise 2
# Name: Chong Zi Kang
# Student No: A0189930R
# Lab Group: T10
*************************************/

//declare your func_list array here
//remember to add in the keyword - extern

extern int (*func_list[5]) (int x);

void update_functions();
